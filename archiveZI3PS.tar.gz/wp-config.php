<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'startproject__db' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'startproject__db' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', 'xapPNcEcv9NONaIw' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'p)}KE>Y,}/tOc$e1q]MILBpnC%T)P1-zL2G:zZiXDl8Lw$IL}fXuVomGK(DTj7nS' );
define( 'SECURE_AUTH_KEY',  'Lk2g$-#G0XMCFa2i|i,X|p0I60.aph._>| k(W Vu[KfgN~^jp[ro)0b7B|po>vD' );
define( 'LOGGED_IN_KEY',    'b@xM@cvRH1tH&2GeHO#FQ1|wkpD:R&V0Rz pF(NLUfl,MR{hA{u1py00(HWvHBFo' );
define( 'NONCE_KEY',        'QJ0mo3:ng43C>OW97IHq.nG=]&d,!8TbvwbfIMb{W~740eIzu{?9_GzuD0YX>NWn' );
define( 'AUTH_SALT',        'd*u-vhg8w(U[W5Y+5:GXI)S_HTmV oB_OiItx)sU;3m-hwOxoL_}y]i_g)}i>r5n' );
define( 'SECURE_AUTH_SALT', 'x:BX1</Hl9gS4Z-~;fVbt1[LU.L!o++rzaXkw+s))^`}M/X}0N?;{J!`/Y*.(s[Z' );
define( 'LOGGED_IN_SALT',   'U&lw.vE}Z_P)LEm{|!On,o;jg~meK<[aRb5}a3.1da.tN0rZ+m5).q:6zv6Q`CUz' );
define( 'NONCE_SALT',       'V[W@)Fz VM{kK&5-[$m%mgduR3*~hVMXsmHeGe;4rsO?<5Ijh8ewx1r>-M!x?d)^' );

/**#@-*/
define('WPCF7_AUTOP', false );
/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', true );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';